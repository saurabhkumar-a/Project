export class ServiceReq{
    Id!: number
    ProductId!: number
    UserId!: number
    ReqDate!: string
    Problem!: string
    Description!: string
    Status!: string
}