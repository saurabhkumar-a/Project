export class Report{
    Id!: number
    ReportDate!: string
    ActionTaken!: string
    DiagnosisDetails!: string
    IsPaid!: string
    VisitFees!: number
    RepairDetails!: string
    SerReqId!: number
    ServiceType!: string
}