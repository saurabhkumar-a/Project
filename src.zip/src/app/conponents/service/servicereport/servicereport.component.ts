import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servicereport',
  templateUrl: './servicereport.component.html',
  styleUrls: ['./servicereport.component.css']
})
export class ServicereportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
