export class Signin{
    name!: string
    password!: string
}