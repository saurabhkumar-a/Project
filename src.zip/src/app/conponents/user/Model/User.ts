export class User{
    Id!: number
    Name!: string
    Email!: string
    Mobile!: number
}