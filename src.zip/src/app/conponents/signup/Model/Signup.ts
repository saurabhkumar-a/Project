export class Signup{
    name!: string
    email!: string
    password!: string
    mobile!: number
}