export class Product{
    Id!: number
    Name!: string
    Make!: string
    Model!: string
    Cost!: number
    CreatedDate!: string
}